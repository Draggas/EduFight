EduFight

===========

Développé par Lucas De jesus teixeira et Louis Beck
Contacts : draggaspro@gmail.com , beck.louis12@gmail.com

# Présentation de EduFight

EduFight est un jeu de combat où un joueur va affronter un autre joueur ou un ordinateur sur une battle de connaissance.

Le système de jeu est simple :

Chaque joueur possède le même point de vie et la même puissance d'attaque, chacun son tour, chaque joueur devront répondre à une question, si ils ont la bonne réponse, leur attaque feront + de dégâts que si ils ont une mauvaise réponse. La partie est terminé lorsque l'un des 2 joueurs n'a plus de point de vie ou lorsque le nombre de round est terminé. Dans ce cas là, le joueur ayant le + de points de vie gagne. 
Des bonus et de rounds spéciaux ont été ajoutés pour rendre le jeu encore plus palpitant et intéressant en même temps de faire cultiver les élèves et son interface va vous ravir. Pour les profs, des fonctionnalités ont été mis en place pour changer les questions dans les matières et les paramètres pour changer le rythme du jeu.

Si vous n'avez pas tout compris, n'hésitez pas à regarder les règles du jeu qui sont mis dans le jeu et les captures d'écran illustrant le fonctionnement du jeu dans le répertoire "shots".
Si vous avez compris les règles, alors bonne partie ! 

# Utilisation de EduFight

Afin d'utiliser le projet, il suffit de taper les commandes suivantes dans un terminal :

```
./compile.sh
```
Permet la compilation des fichiers présents dans 'src' et création des fichiers '.class' dans 'classes'


```
./run.sh
```
Permet le lancement du jeu